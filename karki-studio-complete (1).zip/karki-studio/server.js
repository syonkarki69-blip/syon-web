import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import OpenAI from "openai";
import archiver from "archiver";
import { v4 as uuid } from "uuid";
import { spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.env.DATA_DIR || "./data");
const JOBS_DIR = path.join(DATA_DIR, "jobs");
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 2048);
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

await fs.mkdir(JOBS_DIR, { recursive: true });
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: async (_req, _file, cb) => {
    const dir = path.join(JOBS_DIR, "incoming");
    await fs.mkdir(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (_req, file, cb) => cb(null, `${uuid()}${path.extname(file.originalname).toLowerCase() || ".mp4"}`)
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("video/")) cb(null, true);
    else cb(new Error("Please upload a video file."));
  }
});

const jobs = new Map();
const safeName = (s) => String(s || "clip").replace(/[^a-z0-9-_]/gi, "_").slice(0, 70);
const publicJob = (j) => ({
  id: j.id, status: j.status, progress: j.progress, message: j.message,
  title: j.title, duration: j.duration, clips: j.clips || [], error: j.error || null
});

function run(command, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, ...opts });
    let stderr = "";
    child.stderr.on("data", d => { stderr += d.toString(); if (stderr.length > 12000) stderr = stderr.slice(-12000); });
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve() : reject(new Error(`${command} failed: ${stderr.slice(-3500)}`)));
  });
}
async function ffprobe(file) {
  const { stdout, stderr } = await new Promise((resolve, reject) => {
    const p = spawn("ffprobe", ["-v","error","-show_entries","format=duration:format_tags=title","-of","json",file]);
    let stdout="", stderr="";
    p.stdout.on("data", d => stdout += d); p.stderr.on("data", d => stderr += d);
    p.on("error", reject); p.on("close", c => c === 0 ? resolve({stdout,stderr}) : reject(new Error(stderr)));
  });
  const data = JSON.parse(stdout);
  const duration = Number(data.format?.duration);
  if (!Number.isFinite(duration) || duration <= 0) throw new Error("Could not read video duration. Check that FFmpeg supports this file.");
  return { duration, title: data.format?.tags?.title || path.basename(file) };
}
function parseJson(text) {
  const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  return JSON.parse(cleaned);
}
async function detectHighlights(videoFile, duration) {
  if (!openai) return { segments: [], note: "AI is not configured. Add OPENAI_API_KEY to enable transcript-based highlights." };
  const audioFile = videoFile.replace(/\.[^.]+$/, ".mp3");
  await run("ffmpeg", ["-y","-i",videoFile,"-vn","-ac","1","-ar","16000","-b:a","64k",audioFile]);
  const stat = await fs.stat(audioFile);
  if (stat.size > 24 * 1024 * 1024) {
    // Split audio into chunks to stay within transcription upload limits.
    const chunkDir = path.join(path.dirname(audioFile), "audio_chunks");
    await fs.mkdir(chunkDir, {recursive:true});
    await run("ffmpeg", ["-y","-i",audioFile,"-f","segment","-segment_time","600","-reset_timestamps","1","-c:a","libmp3lame","-b:a","48k",path.join(chunkDir,"part-%03d.mp3")]);
    const names = (await fs.readdir(chunkDir)).filter(n=>n.endsWith(".mp3")).sort();
    let transcript = [];
    for (let i=0;i<names.length;i++) {
      const result = await openai.audio.transcriptions.create({ file: await fs.open(path.join(chunkDir,names[i])).then(h=>h.createReadStream()), model:"whisper-1", response_format:"verbose_json", timestamp_granularities:["segment"] });
      for (const seg of (result.segments || [])) transcript.push({ start: seg.start + i*600, end: seg.end + i*600, text: seg.text });
    }
    await fs.rm(chunkDir,{recursive:true,force:true});
    await fs.rm(audioFile,{force:true});
    return chooseHighlights(transcript, duration);
  }
  const result = await openai.audio.transcriptions.create({
    file: await fs.open(audioFile).then(h=>h.createReadStream()),
    model: "whisper-1", response_format: "verbose_json", timestamp_granularities: ["segment"]
  });
  await fs.rm(audioFile,{force:true});
  return chooseHighlights(result.segments || [], duration);
}
async function chooseHighlights(transcript, duration) {
  const usable = transcript.filter(s => s.end > s.start && s.text?.trim());
  if (!usable.length) return { segments: [], note: "No clear speech was detected. Using evenly spaced clips instead." };
  const prompt = `You are an editor selecting compelling short-form video moments. From this timestamped transcript, select up to 10 self-contained highlights suitable for YouTube Shorts/Reels/TikTok. Each should be 15-60 seconds, avoid starting or ending mid-sentence, favor surprising, useful, emotional, funny or strong-hook moments, and do not invent content. Return ONLY JSON: {"highlights":[{"start":12.3,"end":48.1,"title":"Short title","reason":"Why this moment works"}]}. Video duration: ${duration.toFixed(1)} seconds. Transcript JSON: ${JSON.stringify(usable).slice(0, 85000)}`;
  const response = await openai.chat.completions.create({
    model: process.env.OPENAI_CHAT_MODEL || "gpt-4o-mini",
    temperature: 0.2,
    messages: [
      { role: "system", content: "Return valid JSON only. Timestamps must be within the video duration." },
      { role: "user", content: prompt }
    ],
    response_format: { type: "json_object" }
  });
  const parsed = parseJson(response.choices[0].message.content || "{}");
  const segments = (parsed.highlights || []).map((h,i)=>({
    start: Math.max(0, Number(h.start) || 0),
    end: Math.min(duration, Number(h.end) || 0),
    title: String(h.title || `Highlight ${i+1}`).slice(0,90),
    reason: String(h.reason || "AI-selected moment").slice(0,180)
  })).filter(h=>h.end-h.start >= 8 && h.start < duration).slice(0,10);
  return { segments, note: segments.length ? "Highlights selected from the video transcript." : "AI did not find usable highlights. Using evenly spaced clips instead." };
}
async function renderClip(input, output, start, end) {
  const duration = Math.max(1, end-start);
  await run("ffmpeg", ["-y","-ss",String(start),"-i",input,"-t",String(duration),"-map","0:v:0?","-map","0:a:0?","-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k","-movflags","+faststart","-avoid_negative_ts","make_zero",output]);
}
async function processJob(job, input, opts) {
  try {
    job.status="processing"; job.progress=5; job.message="Reading video information…";
    const info = await ffprobe(input); job.duration=info.duration; job.title=opts.title || info.title;
    let segments=[];
    if (opts.ai === "true" && openai) {
      job.progress=12; job.message="Transcribing audio and finding the best moments with AI…";
      const found = await detectHighlights(input, info.duration);
      segments=found.segments; job.message=found.note;
    } else if (opts.ai === "true" && !openai) {
      job.message="AI key not configured; creating evenly spaced clips instead.";
    }
    if (!segments.length) {
      const length = Math.max(10, Math.min(300, Number(opts.clipLength)||60));
      const max = Number(opts.limit)||0;
      for (let t=0; t<info.duration && (!max || segments.length<max); t+=length) {
        segments.push({start:t,end:Math.min(info.duration,t+length),title:`Clip ${segments.length+1}`,reason:"Sequential segment"});
      }
    }
    if (opts.limit && Number(opts.limit)>0) segments=segments.slice(0,Number(opts.limit));
    const outDir=path.join(JOBS_DIR,job.id,"clips");
    await fs.mkdir(outDir,{recursive:true});
    job.clips=[];
    for (let i=0;i<segments.length;i++) {
      const seg=segments[i], filename=`${String(i+1).padStart(2,"0")}-${safeName(seg.title)}.mp4`;
      const output=path.join(outDir,filename);
      job.message=`Rendering clip ${i+1} of ${segments.length}…`;
      await renderClip(input,output,seg.start,seg.end);
      job.clips.push({ filename, title:seg.title, reason:seg.reason, start:seg.start, end:seg.end,
        url:`/api/jobs/${job.id}/clips/${encodeURIComponent(filename)}` });
      job.progress=20+Math.round(((i+1)/segments.length)*75);
    }
    job.status="completed"; job.progress=100; job.message=`Done! ${job.clips.length} clips are ready.`;
  } catch(err) {
    console.error(err); job.status="error"; job.error=err.message; job.message="Processing failed.";
  }
}

app.post("/api/jobs/upload", upload.single("video"), async (req,res) => {
  if (!req.file) return res.status(400).json({error:"Choose a video file first."});
  const id=uuid(), dir=path.join(JOBS_DIR,id);
  await fs.mkdir(dir,{recursive:true});
  const input=path.join(dir,`source${path.extname(req.file.filename)}`);
  await fs.rename(req.file.path,input);
  const job={id,status:"queued",progress:0,message:"Upload received.",clips:[]}; jobs.set(id,job);
  processJob(job,input,{...req.body,title:req.file.originalname}).catch(console.error);
  res.json(publicJob(job));
});

app.post("/api/jobs/youtube", async (req,res) => {
  const { url }=req.body || {};
  if (!url || !/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url)) return res.status(400).json({error:"Enter a valid YouTube URL."});
  const id=uuid(), dir=path.join(JOBS_DIR,id);
  await fs.mkdir(dir,{recursive:true});
  const job={id,status:"queued",progress:0,message:"Preparing YouTube source…",clips:[]}; jobs.set(id,job);
  res.json(publicJob(job));
  (async()=>{
    try {
      job.status="processing"; job.progress=3; job.message="Importing authorized video…";
      const input=path.join(dir,"source.mp4");
      await run("yt-dlp",["--no-playlist","-f","bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/best","--merge-output-format","mp4","--no-warnings","-o",input,url]);
      await processJob(job,input,req.body);
    } catch(err) { console.error(err); job.status="error"; job.error=err.message; job.message="Could not import this YouTube video. Check the URL, permissions and yt-dlp installation."; }
  })();
});

app.get("/api/jobs/:id", (req,res) => {
  const job=jobs.get(req.params.id);
  if (!job) return res.status(404).json({error:"Job not found. It may have expired after a server restart."});
  res.json(publicJob(job));
});
app.get("/api/jobs/:id/clips/:filename", async (req,res) => {
  const file=path.join(JOBS_DIR,req.params.id,"clips",path.basename(req.params.filename));
  try { await fs.access(file); res.download(file); } catch { res.status(404).json({error:"Clip not found."}); }
});
app.get("/api/jobs/:id/download-all", async (req,res) => {
  const job=jobs.get(req.params.id);
  if (!job || job.status!=="completed") return res.status(404).json({error:"Clips are not ready."});
  res.attachment("karki-studio-clips.zip");
  const archive=archiver("zip",{zlib:{level:5}});
  archive.on("error",err=>res.destroy(err)); archive.pipe(res);
  archive.directory(path.join(JOBS_DIR,job.id,"clips"),false); await archive.finalize();
});

app.get("/api/health",(_req,res)=>res.json({ok:true,aiEnabled:Boolean(openai)}));
app.use((err,_req,res,_next)=>{
  console.error(err);
  const status=err instanceof multer.MulterError ? 400 : 500;
  res.status(status).json({error:err.message || "Unexpected server error."});
});
app.listen(PORT,()=>console.log(`KARKI STUDIO running at http://localhost:${PORT}`));
