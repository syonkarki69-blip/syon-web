const $ = id => document.getElementById(id);
let sourceMode = "upload";
let selectedFile = null;
let activeJob = null;
let pollTimer = null;
let localPreviewUrl = null;

function goTo(page) {
  document.querySelectorAll(".page").forEach(el => el.classList.toggle("hidden", el.id !== page));
  document.querySelectorAll("nav [data-page]").forEach(el => el.classList.toggle("active", el.dataset.page === page));
  window.scrollTo({ top: 0, behavior: "smooth" });
}
document.querySelectorAll("[data-page]").forEach(el => el.addEventListener("click", e => { e.preventDefault(); goTo(el.dataset.page); }));

document.querySelectorAll("[data-source]").forEach(btn => btn.addEventListener("click", () => {
  sourceMode = btn.dataset.source;
  document.querySelectorAll("[data-source]").forEach(b => b.classList.toggle("active", b === btn));
  $("uploadPane").classList.toggle("hidden", sourceMode !== "upload");
  $("youtubePane").classList.toggle("hidden", sourceMode !== "youtube");
}));

$("videoInput").addEventListener("change", e => {
  selectedFile = e.target.files[0] || null;
  $("generateBtn").disabled = !selectedFile;
  $("localPreviewWrap").classList.toggle("hidden", !selectedFile);
  if (localPreviewUrl) URL.revokeObjectURL(localPreviewUrl);
  if (selectedFile) {
    localPreviewUrl = URL.createObjectURL(selectedFile);
    $("localPreview").src = localPreviewUrl;
    setStatus(`Selected: ${selectedFile.name} (${(selectedFile.size/1024/1024).toFixed(1)} MB).`);
  } else setStatus("Choose a source video to get started.");
});
$("youtubeUrl").addEventListener("input", () => {
  $("generateBtn").disabled = !isValidYoutube($("youtubeUrl").value);
});
function isValidYoutube(value) { try { const u=new URL(value); return ["youtube.com","www.youtube.com","m.youtube.com","youtu.be","www.youtu.be"].includes(u.hostname); } catch { return false; } }
function setStatus(message) { $("status").textContent = message; }
function setProgress(value) { $("bar").style.width = `${Math.max(0,Math.min(100,value))}%`; }
function showError(message) { $("error").textContent = message; $("error").classList.remove("hidden"); }
function clearError() { $("error").textContent=""; $("error").classList.add("hidden"); }

$("generateBtn").addEventListener("click", async () => {
  if (activeJob) return;
  clearError(); $("result").classList.add("hidden"); $("clips").replaceChildren(); setProgress(0);
  const form = new FormData();
  form.append("clipLength", $("clipLength").value);
  form.append("limit", $("clipLimit").value);
  form.append("ai", $("aiHighlights").checked ? "true" : "false");
  const endpoint = sourceMode === "upload" ? "/api/jobs/upload" : "/api/jobs/youtube";
  if (sourceMode === "upload") {
    if (!selectedFile) return showError("Please choose a video file.");
    form.append("video", selectedFile);
  } else {
    const url=$("youtubeUrl").value.trim();
    if (!isValidYoutube(url)) return showError("Please enter a valid YouTube URL.");
    form.append("url",url);
  }
  $("generateBtn").disabled=true;
  $("generateBtn").textContent="PROCESSING…";
  setStatus(sourceMode==="upload" ? "Uploading your video…" : "Starting YouTube import…");
  try {
    const response = await fetch(endpoint,{method:"POST",headers:sourceMode==="youtube"?{"Content-Type":"application/json"}:{},body:sourceMode==="youtube"?JSON.stringify(Object.fromEntries(form.entries())):form});
    const data=await response.json();
    if (!response.ok) throw new Error(data.error || "Could not start processing.");
    activeJob=data.id;
    await pollJob();
  } catch(err) {
    showError(err.message); setStatus("Could not start the job."); finishProcessing();
  }
});
async function pollJob() {
  if (!activeJob) return;
  try {
    const response=await fetch(`/api/jobs/${activeJob}`);
    const job=await response.json();
    if (!response.ok) throw new Error(job.error || "Could not read job status.");
    setProgress(job.progress || 0); setStatus(job.message || job.status);
    if (job.status==="completed") { renderClips(job); finishProcessing(); }
    else if (job.status==="error") { showError(job.error || "Processing failed."); finishProcessing(); }
    else pollTimer=setTimeout(pollJob,1800);
  } catch(err) { showError(err.message); finishProcessing(); }
}
function renderClips(job) {
  $("result").classList.remove("hidden");
  $("clipSummary").textContent=`${job.clips.length} clips · ${job.title || "Your video"} · Source duration ${formatTime(job.duration || 0)}`;
  $("downloadAll").href=`/api/jobs/${job.id}/download-all`;
  const frag=document.createDocumentFragment();
  job.clips.forEach((clip,i)=>{
    const card=document.createElement("article"); card.className="clip-card";
    const title=document.createElement("h3"); title.textContent=`${String(i+1).padStart(2,"0")}. ${clip.title}`;
    const video=document.createElement("video"); video.controls=true; video.preload="metadata"; video.src=clip.url;
    const timing=document.createElement("p"); timing.textContent=`${formatTime(clip.start)} – ${formatTime(clip.end)}`;
    const reason=document.createElement("p"); reason.textContent=clip.reason || "";
    const link=document.createElement("a"); link.className="btn"; link.href=clip.url; link.download=clip.filename; link.textContent="DOWNLOAD MP4 ↓";
    card.append(title,video,timing,reason,link); frag.append(card);
  });
  $("clips").replaceChildren(frag);
  $("result").scrollIntoView({behavior:"smooth",block:"start"});
}
function finishProcessing() {
  activeJob=null; $("generateBtn").disabled=false; $("generateBtn").textContent="GENERATE CLIPS";
}
function formatTime(seconds) {
  const n=Math.max(0,Math.floor(seconds||0)), h=Math.floor(n/3600), m=Math.floor((n%3600)/60), s=n%60;
  return h ? `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}` : `${m}:${String(s).padStart(2,"0")}`;
}
$("resetBtn").addEventListener("click",()=>{
  if (pollTimer) clearTimeout(pollTimer);
  activeJob=null; selectedFile=null; $("videoInput").value=""; $("youtubeUrl").value="";
  $("generateBtn").disabled=true; $("generateBtn").textContent="GENERATE CLIPS";
  $("localPreview").removeAttribute("src"); $("localPreviewWrap").classList.add("hidden");
  if(localPreviewUrl) URL.revokeObjectURL(localPreviewUrl); localPreviewUrl=null;
  $("result").classList.add("hidden"); $("clips").replaceChildren(); clearError(); setProgress(0);
  setStatus("Choose a source video to get started.");
});
fetch("/api/health").then(r=>r.json()).then(data=>{
  if(!data.aiEnabled) $("status").textContent="Ready. AI highlights are enabled in the interface, but the server has no OPENAI_API_KEY; sequential clipping will be used until you configure one.";
}).catch(()=>{});
goTo("home");
