# KARKI STUDIO

A black-and-gold long-video clipping web app. It supports local video uploads and YouTube URLs, sequential clip generation, optional transcript-based AI highlight selection, MP4 downloads, and ZIP export.

## Requirements

- Node.js 20 or newer
- FFmpeg and FFprobe installed and available on your PATH
- yt-dlp installed and available on your PATH (only needed for YouTube URL import)
- An OpenAI API key (optional; required for AI transcription/highlight selection)

## Install

1. Extract this folder.
2. Open a terminal in the project folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env` and add your OpenAI key if you want AI highlights:

   ```env
   OPENAI_API_KEY=your_api_key_here
   OPENAI_CHAT_MODEL=gpt-4o-mini
   PORT=3000
   ```

5. Install system tools:
   - Windows: install FFmpeg (including `ffprobe`) and yt-dlp, then add both to PATH.
   - macOS: `brew install ffmpeg yt-dlp`
   - Ubuntu/Debian: `sudo apt update && sudo apt install ffmpeg` and install yt-dlp using its official installation instructions.

6. Start the server:

   ```bash
   npm start
   ```

7. Open **http://localhost:3000** in your browser.

## How it works

- Upload mode sends the video to the Node server.
- YouTube mode invokes `yt-dlp` on the server to import the URL.
- FFprobe reads the source duration.
- If AI is enabled and `OPENAI_API_KEY` is set, FFmpeg extracts audio, OpenAI Whisper transcribes it, and a chat model selects timestamped highlight windows.
- FFmpeg renders each selected segment to MP4 (H.264/AAC).
- The browser polls job status and displays individual downloads plus a ZIP download.

If AI is disabled, no API key is configured, or no usable transcript highlights are found, the app creates sequential clips using the selected duration.

## Important notes

- Use YouTube import only for videos you own or have explicit permission to download and process. Respect copyright, YouTube's Terms of Service, and local laws. This starter does not bypass DRM, private-video restrictions, or access controls.
- Do not expose `.env` or your OpenAI API key in frontend code. The key belongs only on the server.
- This is a local-development starter, not a hardened public production service. Before deploying publicly, add authentication, per-user job isolation, rate limits, quotas, upload scanning, HTTPS, persistent job storage/queueing, cleanup policies, and monitoring.
- Jobs are held in server memory for status tracking; restarting the server loses their status. Video files are stored under `data/jobs`.
- The 2 GB default upload limit is configurable with `MAX_UPLOAD_MB`.
- AI highlight selection uses spoken transcript content; it is not full visual scene understanding. Very long audio is split into 10-minute chunks for transcription.
- This version outputs standard landscape clips. Vertical 9:16 reframing, animated captions, face tracking, and branded templates can be added as a next iteration.

## Troubleshooting

- `ffmpeg not found` / `ffprobe not found`: install FFmpeg and make sure the binaries are on PATH, then restart the terminal.
- `yt-dlp failed`: update yt-dlp, check that the video is public/available to your account and that you have permission to process it.
- AI not running: confirm `.env` exists, `OPENAI_API_KEY` is valid, and restart `npm start`.
- Upload too large: raise `MAX_UPLOAD_MB` in `.env`, subject to available disk space and server limits.
